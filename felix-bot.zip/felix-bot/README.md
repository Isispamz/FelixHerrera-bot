# Félix Herrera Bot (MVP)
1) Copia `.env.example` a `.env` y llena variables.
2) `npm i` y `node server.js`.
3) Expón con ngrok y configura el webhook en Meta con `/webhook`.
4) Envía un WhatsApp a tu número de Cloud y prueba.
